import sys
from bardapi import Bard

def get_bard_answer(question, token):
    bard = Bard(token=token)
    return bard.get_answer(question)['content']

if __name__ == "__main__":
    question = sys.argv[1]
    token = sys.argv[2]
    answer = get_bard_answer(question, token)
    print(answer)